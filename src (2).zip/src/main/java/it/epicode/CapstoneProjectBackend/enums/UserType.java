package it.epicode.CapstoneProjectBackend.enums;

public enum UserType {
    USER, ADMIN
}
