package it.epicode.CapstoneProjectBackend.controller;

import it.epicode.CapstoneProjectBackend.Service.LyricsServiceWithTranslation;
import it.epicode.CapstoneProjectBackend.dto.LyricsLineDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class LyricsController {

    @Autowired
    private LyricsServiceWithTranslation lyricsServiceWithTranslation;

    @GetMapping("/lyrics")
    public List<LyricsLineDto> getLyricsWithTranslation(@RequestParam String artista,
                                                        @RequestParam String titolo) {
        return lyricsServiceWithTranslation.getTranslatedLyrics(artista, titolo);
    }
    @GetMapping("/test-translate")
    public String testTraduzioneSingola(@RequestParam String frase) {
        return lyricsServiceWithTranslation.traduciConDeepL(frase);
    }
    @GetMapping("/api/test-deepl")
    public String testTraduzione(@RequestParam String frase) {
        System.out.println("🧪 Chiamata ricevuta con frase: " + frase);
        return lyricsServiceWithTranslation.traduciConDeepL(frase);
    }

}
