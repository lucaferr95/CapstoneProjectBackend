package it.epicode.CapstoneProjectBackend.dto;

public class LyricsLineDto {
    private String originale;
    private String tradotta;

    public LyricsLineDto(String originale, String tradotta) {
        this.originale = originale;
        this.tradotta = tradotta;
    }

    public String getOriginale() {
        return originale;
    }

    public String getTradotta() {
        return tradotta;
    }

    public void setOriginale(String originale) {
        this.originale = originale;
    }

    public void setTradotta(String tradotta) {
        this.tradotta = tradotta;
    }
}
