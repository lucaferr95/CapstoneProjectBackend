package it.epicode.CapstoneProjectBackend.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class LyricsResponseDto {
    private String titolo;
    private String artista;
    private String testo;
    private String traduzione;
}
