package it.epicode.CapstoneProjectBackend.Service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import it.epicode.CapstoneProjectBackend.dto.LyricsLineDto;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

@Service
public class LyricsServiceWithTranslation {

    private final String MUSIXMATCH_HOST = "musixmatch-song-lyrics-api.p.rapidapi.com";
    private final String MUSIXMATCH_BASE_URL = "https://musixmatch-song-lyrics-api.p.rapidapi.com/lyrics";
    private final String MUSIXMATCH_API_KEY = "a22555931amshab02c3c1b6cef33p1a28a7jsn525dd46aa6c5";

    private final String DEEPL_API_KEY = "44f3522f-639b-4114-a2dc-215359ac9d62:fx";
    private final String DEEPL_URL = "https://api-free.deepl.com/v2/translate";

    private final RestTemplate restTemplate = new RestTemplate();
    private final ObjectMapper mapper = new ObjectMapper();

    public List<LyricsLineDto> getTranslatedLyrics(String artist, String title) {
        try {
            String encodedArtist = URLEncoder.encode(artist, StandardCharsets.UTF_8);
            String encodedTitle = URLEncoder.encode(title, StandardCharsets.UTF_8);

            // 1. Ottieni il testo
            URI uri = new URI(MUSIXMATCH_BASE_URL + "/" + encodedArtist + "/" + encodedTitle + "/");
            HttpHeaders headers = new HttpHeaders();
            headers.set("X-RapidAPI-Key", MUSIXMATCH_API_KEY);
            headers.set("X-RapidAPI-Host", MUSIXMATCH_HOST);

            HttpEntity<String> entity = new HttpEntity<>(headers);
            ResponseEntity<String> response = restTemplate.exchange(uri, HttpMethod.GET, entity, String.class);

            JsonNode json = mapper.readTree(response.getBody());
            JsonNode lyricsNode = json.path("lyrics");

            if (lyricsNode.isMissingNode()) return rigaUnica("Testo non disponibile", "Traduzione non disponibile");

            String lyrics = lyricsNode.asText();
            String[] righe = lyrics.split("\n");

            // 2. Traduce ogni riga con DeepL
            List<LyricsLineDto> output = new ArrayList<>();
            for (String riga : righe) {
                if (riga.strip().isEmpty()) continue;

                String tradotta = traduciConDeepL(riga);
                output.add(new LyricsLineDto(riga, tradotta));
            }

            return output;

        } catch (Exception e) {
            e.printStackTrace();
            return rigaUnica("Errore durante il recupero", "Errore nella traduzione");
        }
    }

    public String traduciConDeepL(String testo) {
        try {
            URI uri = new URI("https://api-free.deepl.com/v2/translate");

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.set("Authorization", "DeepL-Auth-Key 44f3522f-639b-4114-a2dc-215359ac9d62:fx"); // 🔐 Sostituisci qui

            // Corpo JSON con testo e lingua
            String jsonBody = String.format("""
            {
              "text": ["%s"],
              "target_lang": "IT"
            }
        """, testo.replace("\"", "\\\"")); // ↩️ Protegge eventuali doppi apici

            HttpEntity<String> entity = new HttpEntity<>(jsonBody, headers);
            ResponseEntity<String> response = restTemplate.exchange(uri, HttpMethod.POST, entity, String.class);

            System.out.println("🌐 STATUS: " + response.getStatusCode());
            System.out.println("🧾 BODY: " + response.getBody());

            JsonNode root = mapper.readTree(response.getBody());
            JsonNode result = root.at("/translations/0/text");

            System.out.printf("🔤 Traduzione: \"%s\" → \"%s\"%n", testo, result.asText());

            return result.isMissingNode() ? "Traduzione non disponibile" : result.asText();

        } catch (Exception e) {
            e.printStackTrace();
            return "Errore nella traduzione";
        }
    }



    private List<LyricsLineDto> rigaUnica(String o, String t) {
        List<LyricsLineDto> lista = new ArrayList<>();
        lista.add(new LyricsLineDto(o, t));
        return lista;
    }
}
