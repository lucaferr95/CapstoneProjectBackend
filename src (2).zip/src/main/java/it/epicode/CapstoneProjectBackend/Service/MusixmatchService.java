package it.epicode.CapstoneProjectBackend.Service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import it.epicode.CapstoneProjectBackend.dto.LyricsResponseDto;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

@Service
public class MusixmatchService {

    private final String API_KEY = "a22555931amshab02c3c1b6cef33p1a28a7jsn525dd46aa6c5";
    private final String API_HOST = "musixmatch-song-lyrics-api.p.rapidapi.com";
    private final String BASE_URL = "https://musixmatch-song-lyrics-api.p.rapidapi.com";

    private final RestTemplate restTemplate = new RestTemplate();
    private final ObjectMapper mapper = new ObjectMapper();

    public LyricsResponseDto getLyricsAndTranslation(String artista, String titolo) {
        Integer trackId = searchTrackId(artista, titolo);
        if (trackId == null) {
            return new LyricsResponseDto(titolo, artista, "Testo non disponibile.", "Traduzione non disponibile.");
        }

        String lyrics = getLyrics(trackId);
        return new LyricsResponseDto(titolo, artista, lyrics, "Traduzione non disponibile (endpoint non disponibile).");
    }

    private Integer searchTrackId(String artista, String titolo) {
        try {
            String encodedArtist = URLEncoder.encode(artista, StandardCharsets.UTF_8);
            String encodedTitle = URLEncoder.encode(titolo, StandardCharsets.UTF_8);

            URI uri = new URI(BASE_URL + "/track.search?q_track=" + encodedTitle +
                    "&q_artist=" + encodedArtist + "&page_size=1&page=1&s_track_rating=desc");

            HttpHeaders headers = new HttpHeaders();
            headers.set("X-RapidAPI-Key", API_KEY);
            headers.set("X-RapidAPI-Host", API_HOST);

            HttpEntity<String> entity = new HttpEntity<>(headers);
            ResponseEntity<String> response = restTemplate.exchange(uri, HttpMethod.GET, entity, String.class);

            JsonNode root = mapper.readTree(response.getBody());
            JsonNode trackIdNode = root.at("/message/body/track_list/0/track/track_id");

            return trackIdNode.isMissingNode() ? null : trackIdNode.asInt();

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private String getLyrics(Integer trackId) {
        try {
            URI uri = new URI(BASE_URL + "/track.lyrics.get?track_id=" + trackId);

            HttpHeaders headers = new HttpHeaders();
            headers.set("X-RapidAPI-Key", API_KEY);
            headers.set("X-RapidAPI-Host", API_HOST);

            HttpEntity<String> entity = new HttpEntity<>(headers);
            ResponseEntity<String> response = restTemplate.exchange(uri, HttpMethod.GET, entity, String.class);

            JsonNode root = mapper.readTree(response.getBody());
            JsonNode lyricsNode = root.at("/message/body/lyrics/lyrics_body");

            return lyricsNode.isMissingNode() ? "Testo non disponibile." : lyricsNode.asText().trim();

        } catch (Exception e) {
            e.printStackTrace();
            return "Testo non disponibile.";
        }
    }
}
