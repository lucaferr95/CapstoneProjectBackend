package it.epicode.CapstoneProjectBackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CapstoneProjectBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(CapstoneProjectBackendApplication.class, args);
	}

}
